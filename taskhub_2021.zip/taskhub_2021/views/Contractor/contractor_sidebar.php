<?php ?>
<div class="sidebar">
    <ul>
        <li class="top"><a href="#"><i class="fa fa-search"></i> Search</a></li>
        <li><a href="<?php echo fullURLfront; ?>/contractor/contractor_profile"><i class="fa fa-user"></i> Profile</a></li>
        <li><a href="#"><i class="fa fa-calendar"></i> Booking</a></li>
        <li><a href="#"><i class="fa fa-audio-description"></i> View Advertsiment</a></li>
        <li><a href="#"><i class="fa fa-audio-description"></i>Post Advertisement</a></li>
        <li><a href="#"><i class="fa fa-frown-o"></i> Complaints</a></li>
        <li><a href="#"><i class="fa fa-history"></i> History</a></li>
        <li><a href="#"><i class="fa fa-info-circle"></i> Help</a></li>
    </ul>
</div>