<?php ?>
<div class="sidebar">
    <ul>
        <li class="top"><a href="<?php echo fullURLfront; ?>/Employee/employee_search"><i class="fa fa-search"></i> Search</a></li>
        <li><a href="<?php echo fullURLfront; ?>/Employee/employee_profile"><i class="fa fa-user"></i> Profile</a></li>
        <li><a href="<?php echo fullURLfront; ?>/Employee/employee_booking"><i class="fa fa-calendar"></i> Booking</a></li>
        <li><a href="<?php echo fullURLfront; ?>/Employee/employee_complaint"><i class="fa fa-frown-o"></i> Complaints</a></li>
        <li><a href="<?php echo fullURLfront; ?>/Employee/employee_history"><i class="fa fa-history"></i> History</a></li>
        <li><a href="<?php echo fullURLfront; ?>/Employee/employee_help"><i class="fa fa-info-circle"></i> Help</a></li>
        <li><a href="<?php echo fullURLfront; ?>/Employee/employee_viewad"><i class="fa fa-audio-description"></i> View Advertsiment</a></li>
    </ul>
</div>